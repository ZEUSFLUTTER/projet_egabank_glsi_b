import { Component } from '@angular/core';

@Component({
  selector: 'app-client-form',
  imports: [],
  templateUrl: './client-form.html',
  styleUrl: './client-form.css',
})
export class ClientForm {

}
