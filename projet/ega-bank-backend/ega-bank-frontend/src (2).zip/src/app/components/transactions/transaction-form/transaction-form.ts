import { Component } from '@angular/core';

@Component({
  selector: 'app-transaction-form',
  imports: [],
  templateUrl: './transaction-form.html',
  styleUrl: './transaction-form.css',
})
export class TransactionForm {

}
