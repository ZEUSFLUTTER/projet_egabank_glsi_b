import { Component } from '@angular/core';

@Component({
  selector: 'app-account-form',
  imports: [],
  templateUrl: './account-form.html',
  styleUrl: './account-form.css',
})
export class AccountForm {

}
