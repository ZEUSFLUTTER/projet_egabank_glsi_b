import { Component } from '@angular/core';

@Component({
  selector: 'app-client-list',
  imports: [],
  templateUrl: './client-list.html',
  styleUrl: './client-list.css',
})
export class ClientList {

}
